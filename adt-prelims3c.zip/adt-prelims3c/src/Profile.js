import React from 'react';

const Profile = ({ user }) => (
  <div style={{ marginTop: '20px' }}>
    <h2>Welcome, {user}</h2>
    <p>Status= Admin</p>
    <p>Bio= Life Sucks .</p>
  </div>
);

export default Profile;