import React, { useReducer, useState } from 'react';

const mathReducer = (state, action) => {
  switch (action.type) {
    case 'ADD':
      return state + action.payload;
    case 'SUBTRACT':
      return state - action.payload;
    case 'MULTIPLY':
      return state * action.payload;
    case 'DIVIDE':
      return state / action.payload;
    default:
      return state;
  }
};

const MathOperation = () => {
  const [state, dispatch] = useReducer(mathReducer, 0);
  const [num, setNum] = useState(0);

  return (
    <div>
      <h2>Math Operations</h2>
      <input type="number" value={num} onChange={(e) => setNum(Number(e.target.value))} />
      <button onClick={() => dispatch({ type: 'ADD', payload: num })}>Add</button>
      <button onClick={() => dispatch({ type: 'SUBTRACT', payload: num })}>Subtract</button>
      <button onClick={() => dispatch({ type: 'MULTIPLY', payload: num })}>Multiply</button>
      <button onClick={() => dispatch({ type: 'DIVIDE', payload: num })}>Divide</button>
      <h3>Result: {state}</h3>
    </div>
  );
};

export default MathOperation;