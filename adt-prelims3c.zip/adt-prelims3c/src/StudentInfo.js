import React from 'react';

const StudentInfo = ({ name, section }) => (
  <div style={{ textAlign: 'Top', padding: '50px', backgroundColor: '#f5f5f5' }}>
    <h1>Student Information</h1>
    <p>Complete Name: {name}</p>
    <p>Section: {section}</p>
  </div>
);

export default StudentInfo;