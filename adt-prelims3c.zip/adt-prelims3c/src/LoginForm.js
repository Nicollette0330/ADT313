import React, { useState, useRef, useEffect, useCallback } from 'react';

const LoginForm = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const usernameRef = useRef();
  const passwordRef = useRef();

  const storedCredentials = useRef({
    username: 'Admin',
    password: 'Admin123'
  });
  

  const validateForm = useCallback(() => {
    if (!username || !password) {
      setError('Username and Password are required');
      return false;
    }
    setError('');
    return true;
  }, [username, password]);

  const handleLogin = useCallback((e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    setTimeout(() => {
      if (
        username === storedCredentials.current.username &&
        password === storedCredentials.current.password
      ) {
        onLogin(username);
      } else {
        setError('Invalid credentials');
      }
      setLoading(false);
    }, 3000);
  }, [username, password, onLogin, validateForm]);

  const toggleShowPassword = useCallback(() => {
    setShowPassword(!showPassword);
  }, [showPassword]);

  return (
    <form onSubmit={handleLogin} style={{ marginTop: '20px' }}>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div>
        <label>Username:</label>
        <input
          ref={usernameRef}
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />
      </div>
      <div>
        <label>Password:</label>
        <input
          ref={passwordRef}
          type={showPassword ? 'text' : 'password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="button" onClick={toggleShowPassword}>
          {showPassword ? 'Hide' : 'Show'} Password
        </button>
      </div>
      <button type="submit">{loading ? 'Loading...' : 'Login'}</button>
    </form>
  );
};

export default LoginForm;