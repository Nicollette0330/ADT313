import React, { useState, useEffect } from 'react';
import './App.css';
import StudentInfo from './StudentInfo';
import LoginForm from './LoginForm';
import Profile from './Profile';
import MathOperation from './MathOperation';
import { useProfile, ProfileProvider } from './ProfileContext';

const App = () => {
  const { profile, login, logout } = useProfile();
  const [theme, setTheme] = useState('light');

  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      logout();
    }
  };

  return (
    <div className={`App ${theme}`}>
      <StudentInfo name="Nicollette Edilbert B. Mendoza" section="BSIT-3C" />
      <button onClick={toggleTheme}>
        Switch to {theme === 'light' ? 'Dark' : 'Light'} Theme
      </button>

      {!profile ? (
        <LoginForm onLogin={login} />
      ) : (
        <>
          <Profile user={profile.username} />
          <MathOperation />
          <button onClick={handleLogout}>Logout</button>
        </>
      )}
    </div>
  );
};

const RootApp = () => (
  <ProfileProvider>
    <App />
  </ProfileProvider>
);

export default RootApp;